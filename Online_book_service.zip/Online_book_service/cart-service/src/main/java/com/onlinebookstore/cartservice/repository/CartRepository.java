package com.onlinebookstore.cartservice.repository;

import com.onlinebookstore.cartservice.model.Cart;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartRepository extends JpaRepository<Cart, Long> {
 
public Cart findByCartId(int id);
}