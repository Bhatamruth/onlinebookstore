package com.onlinebookstore.cartservice.controller;

import com.onlinebookstore.cartservice.model.Cart;
import com.onlinebookstore.cartservice.model.CartItem;
import com.onlinebookstore.cartservice.model.Product;
import com.onlinebookstore.cartservice.service.CartService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api/carts")
public class CartController {

	
	private final RestTemplate restTemplate;
    @Autowired
    public CartController(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder.build();
    }
    @Autowired
    private CartService cartService;

    
    @GetMapping("/getCartList")
    public List<Cart> getCartList()
    {
    	return cartService.getAll();
    }
    @GetMapping("/getCartId/{cartId}")
    public Cart getCartId(@PathVariable("cartId") int cartId) {
        return cartService.getByCartId(cartId);
    }

    
    @PostMapping("/newCart/{cartId}/{id}/{quantity}")
    public Cart addCart(
            @PathVariable("cartId") int cartId,
            @PathVariable("id") int id,
            @PathVariable("quantity") int quantity) {

        Cart cart = cartService.getByCartId(cartId);
        Cart cart2 = new Cart();

        if (cart == null) {
            // Use restTemplate to make a REST call
            Product product = restTemplate.getForObject("http://localhost:8080/getBookById/" + id, Product.class);
   		
    		product.setQuantity(quantity);
    		
    		
    		double updatePrice = product.getPrice() * quantity;
    		product.setPrice(updatePrice);
    		
    		List<Product> products = new ArrayList<>();
    		
    		products.add(product);
    		cart2.setCartId(cartId);
    		cart2.setProduct(products);
    		cart2.setTotal(updatePrice);
    		
    		return cartService.addBookIntoCart(cart2);}
        else {}
		return cart;
    	}
    }

