package com.onlinebookstore.cartservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinebookstore.cartservice.model.Cart;
import com.onlinebookstore.cartservice.repository.CartRepository;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    public List<Cart> getAll() {
        return cartRepository.findAll();
    }

    public Cart getByCartId(int id) {
        return cartRepository.findByCartId( id);
    }

    public Cart addBookIntoCart(Cart cart) {
        return cartRepository.save(cart);
    }

    public String deleteCart(int id) {
    	
    	Cart cart = cartRepository.findByCartId(id);
    	
        cartRepository.delete(cart);
		return "deleted";
    }
}
