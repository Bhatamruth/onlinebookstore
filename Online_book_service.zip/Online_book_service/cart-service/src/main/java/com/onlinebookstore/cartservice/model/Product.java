package com.onlinebookstore.cartservice.model;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Product {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Integer id;
  
  public void setId(Integer id) {
    this.id = id;
  }

  private String name;
  private float price;
 
  private String category; // Added category field
private int quantity;
  
  public Product() {
  }
 
  /**
   * Creates a new Product instance with the specified ID, name, and price.
   *
   * @param id    The unique identifier for the product.
   * @param name  The name of the product.
   * @param price The price of the product.
   */
  public Product(Integer id, String name, float price, String category) {
    this.id = id;
    this.setName(name);
    this.setPrice(price);
    this.setCategory(category);
  }
 
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Integer getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public float getPrice() {
    return price;
  }

  public void setPrice(double updatePrice) {
    this.price = (float) updatePrice;
  }
	

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

public void setQuantity(int quantity) {
	// TODO Auto-generated method stub
	this.quantity = quantity;;
}
 
  // other getters and setters...
}




