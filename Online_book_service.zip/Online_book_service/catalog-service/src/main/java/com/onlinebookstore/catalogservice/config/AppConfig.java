package com.onlinebookstore.catalogservice.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
/**
 * This class serves as a configuration class for the Spring application.
 * It defines and configures various beans and components used in the application.
 * You can use the {@code @Configuration} annotation to declare this class as a
 * configuration source.
 *
 * @author amruth
 * @since 1.0
 */

@Configuration
public class AppConfig {	
  /**
   * This method defines a Spring bean that provides a specific functionality.
   * You can use this bean by injecting it into other Spring components.
   *
   * @return An instance of the bean that provides the specified functionality.
   */
  @Bean
  public UserDetailsService userDetailsService() {
    UserDetails userDetails = User.builder()
        .username("amruth")
        .password(passwordEncoder().encode("1234")).roles("ADMIN")
        .build();
    return new InMemoryUserDetailsManager(userDetails);
  }
	
  @Bean
  public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
  }
	
  @Bean
  public AuthenticationManager authenticationManager(AuthenticationConfiguration builder) 
      throws Exception{
    return builder.getAuthenticationManager();
  }

}
