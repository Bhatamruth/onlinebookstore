package com.onlinebookstore.catalogservice.service;

 
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.onlinebookstore.catalogservice.model.Product;
import com.onlinebookstore.catalogservice.repository.ProductRepository;

/**
 * This class represents a service component in the application.
 * 
 * <p>
 * A service component is responsible for providing specific functionality
 * or services within the application. It may be used to perform business
 * logic, handle data access, or perform other tasks.
 * </p>
 * 
 * <p>
 * Example usage:
 * <pre>
 * {@code
 *   @Service
 *   public class MyService {
 *       // ... class implementation ...
 *   }
 * }
 * </pre>
 * </p>
 */
@SuppressWarnings("unused")
@Service 
@Transactional
public class ProductService {
 
  @Autowired
  private ProductRepository repo;
  
  public List<Product> listAll() {
    return repo.findAll();
  }
     
  public Product save(Product product) {
      // Save the product and return the saved entity
      return repo.save(product);
  }
     
  
  public List<Product> getAllProducts() {
      return repo.findAll();
  }
  
  
  public Product get(Integer id) {
    return repo.findById(id).get();
  }
     
 
  public Product delete(Integer id) {
      // Check if the product exists
      Product product = repo.findById(id).orElseThrow(() -> new NoSuchElementException("Product with ID " + id + " not found"));

      // If the product exists, delete it and return the deleted product
      repo.deleteById(id);
      return product;
  }
  
 
  public List<Product> getProductsByCategory(String category) {
    // TODO Auto-generated method stub
    return repo.findByCategory(category);
  }

public List<Product> getProductsByCategoryAndPriceRange(String category, Double minPrice, Double maxPrice) {
	// TODO Auto-generated method stub
	return repo.findByCategoryAndPriceBetween(category, minPrice, maxPrice);
}

}






