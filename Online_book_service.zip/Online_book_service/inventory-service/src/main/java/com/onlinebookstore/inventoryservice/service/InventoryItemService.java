package com.onlinebookstore.inventoryservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinebookstore.inventoryservice.model.InventoryItem;
import com.onlinebookstore.inventoryservice.repository.InventoryItemRepository;

@Service
public class InventoryItemService {

    @Autowired
    private InventoryItemRepository inventoryItemRepository;

    public List<InventoryItem> getInventoryItemsByProductId(Long productId) {
        return inventoryItemRepository.findByProductId(productId);
    }

    // Other methods for managing inventory items
}
