package com.onlinebookstore.inventoryservice.repository;

 
import com.onlinebookstore.inventoryservice.model.InventoryItem;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryItemRepository extends JpaRepository<InventoryItem, Long> {

    List<InventoryItem> findByProductId(Long productId);
}
