package com.onlinebookstore.inventoryservice.service;

 
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ProductService {

    private final RestTemplate restTemplate;

    @Autowired
    public ProductService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getAllProducts() {
         
        String url = "http://localhost:8080/products";
        return restTemplate.getForObject(url, String.class);
    }
}
