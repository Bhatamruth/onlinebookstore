package com.onlinebookstore.userservice.service;

public class UserRegistrationException extends RuntimeException {
    public UserRegistrationException(String message) {
        super(message);
    }
}

 



 

