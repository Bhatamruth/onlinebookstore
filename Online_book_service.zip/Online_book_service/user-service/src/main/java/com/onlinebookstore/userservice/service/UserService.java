package com.onlinebookstore.userservice.service;

import com.onlinebookstore.userservice.service.UserAuthenticationException;
import com.onlinebookstore.userservice.service.UserNotFoundException;
import com.onlinebookstore.userservice.service.UserRegistrationException;

import jakarta.transaction.Transactional;
                                                                                                   
import com.onlinebookstore.userservice.model.User;
import com.onlinebookstore.userservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;





@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public User authenticateUser(String email, String password) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UserAuthenticationException("User not found"));

        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new UserAuthenticationException("Invalid credentials");
        }

        return user;
    }

    public User getUserById(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found"));
    }

    @Transactional
    public User registerUser(User user) {
        validateUserRegistration(user);

        // Check if the email is already registered
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new UserRegistrationException("Email is already registered");
        }

        // Encrypt the password before saving
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // Save the user
        return userRepository.save(user);
    }

    private void validateUserRegistration(User user) {
        // Perform validation, e.g., check password complexity, email format, etc.
        // Throw UserRegistrationException if validation fails
    }
}
